(function(){
var s = "<"+"div id=\"537975067_INSERT_SLOT_ID_HERE\" style=\"width:300px;height:250px;margin:0;padding:0\">\n";
s += "  <"+"noscript><"+"iframe id=\"7387471f01\" name=\"7387471f01\" src=\"http://us-ads.openx.net/w/1.0/afr?auid=537975067&cb=INSERT_RANDOM_NUMBER_HERE\" frameborder=\"0\" scrolling=\"no\" width=\"300\" height=\"250\"><"+"a href=\"http://us-ads.openx.net/w/1.0/rc?cs=7387471f01&cb=INSERT_RANDOM_NUMBER_HERE\" ><"+"img src=\"http://us-ads.openx.net/w/1.0/ai?auid=537975067&cs=7387471f01&cb=INSERT_RANDOM_NUMBER_HERE\" border=\"0\" alt=\"\"><"+"/a><"+"/iframe><"+"/noscript>\n";
s += "<"+"/div>\n";
s += "<"+"script type=\"text/javascript\">\n";
s += "  var OX_ads = OX_ads || [];\n";
s += "  OX_ads.push({\n";
s += "     slot_id: \"537975067_INSERT_SLOT_ID_HERE\",\n";
s += "     auid: \"537975067\"\n";
s += "  });\n";
s += "<"+"/script>\n";
s += "<"+"script type=\"text/javascript\" src=\"http://us-ads.openx.net/w/1.0/jstag\"><"+"/script>\n";
s += "<"+"div id=\'beacon_bf1648a5ef\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"http://cat.ny.us.criteo.com/delivery/lg.php?cppv=1&cpp=A4pLPnx0TlBUZU5xUHh1ck51b2lOOXdyOVJEKzZSbHFlZFJHU0hkUE9NdmorZGNQOW9vbGEyb2gzclJ0TmtVWnJaeml4YkozdGZ6TGdkV05NNExHL0NvSjJPc1RPMUE1VWVidmQrRU43dno1bUhDQ05ucTVyc09OQm9YSHJOQVJ4dWpncUxSL21SSkJzMFBtM0gzNWtMZk5BZ0J4UGgzZVBMKytQYlh6Y2JSMFBmTW1uYWtHSDVDa0ZFa0pnTUVNNDAyL3VQUzJlak9YK3EweDUvc3lWWUlZMUdPekpVZ3FGNFc5WTRmT2RyT293YVpjPXw%3D\"/>\n";
s += "<"+"/div>\n";
s += "\n";
document.write(s);})();
