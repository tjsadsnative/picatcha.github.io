(function(){
var s = "<"+"div id=\"537975067_INSERT_SLOT_ID_HERE\" style=\"width:300px;height:250px;margin:0;padding:0\">\n";
s += "  <"+"noscript><"+"iframe id=\"7387471f01\" name=\"7387471f01\" src=\"http://us-ads.openx.net/w/1.0/afr?auid=537975067&cb=INSERT_RANDOM_NUMBER_HERE\" frameborder=\"0\" scrolling=\"no\" width=\"300\" height=\"250\"><"+"a href=\"http://us-ads.openx.net/w/1.0/rc?cs=7387471f01&cb=INSERT_RANDOM_NUMBER_HERE\" ><"+"img src=\"http://us-ads.openx.net/w/1.0/ai?auid=537975067&cs=7387471f01&cb=INSERT_RANDOM_NUMBER_HERE\" border=\"0\" alt=\"\"><"+"/a><"+"/iframe><"+"/noscript>\n";
s += "<"+"/div>\n";
s += "<"+"script type=\"text/javascript\">\n";
s += "  var OX_ads = OX_ads || [];\n";
s += "  OX_ads.push({\n";
s += "     slot_id: \"537975067_INSERT_SLOT_ID_HERE\",\n";
s += "     auid: \"537975067\"\n";
s += "  });\n";
s += "<"+"/script>\n";
s += "<"+"script type=\"text/javascript\" src=\"http://us-ads.openx.net/w/1.0/jstag\"><"+"/script>\n";
s += "<"+"div id=\'beacon_9b6c2439b2\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"http://cat.ny.us.criteo.com/delivery/lg.php?cppv=1&cpp=Ox93M3x0TlBUZU5xUHh1ck51b2lOOXdyOVJKdys4VjU5UkpoNGMxcURVSjUxQ2NLeWtETHR0d3IxaCtUV0hhdk05ZkZHVU13Q3BtMEREMzBCTkNOWFlLUjBiYjlWWEVrTkUwWC9RajRCekFKTkltbHhvcCt0SE9YNGtOM0ZCNlhSVUIrRzloQXFvMjdDNWlhSEJ0UGRNUTlnTkYyRHFpakpjWGJocmRlK3JodURmK0l1ejltZzBoV0N6bUdYV2w5NEExRTJVUG1BY2dReHlpVE5ZSS82aVlqSS9QUWNONEIrbDBkSVkxb1MrQjBFYndjPXw%3D\"/>\n";
s += "<"+"/div>\n";
s += "\n";
document.write(s);})();
