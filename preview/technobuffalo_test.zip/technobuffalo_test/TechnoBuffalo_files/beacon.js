if(typeof COMSCORE=="undefined"){var COMSCORE={}}if(typeof _comscore!="object"){var _comscore=[]}COMSCORE.beacon=function(k){try{if(!k){return}var i=1.8,l=k.options||{},j=l.doc||document,b=l.nav||navigator,g=j.location,f=512,d=function(e,m){if(e==null){return""}e=(encodeURIComponent||escape)(e);if(m){e=e.substr(0,m)}return e},a=[(g.protocol=="https:"?"https://sb":"http://b"),".scorecardresearch.com/b?","c1=",d(k.c1),"&c2=",d(k.c2),"&rn=",Math.random(),"&c7=",d(g.href,f),"&c3=",d(k.c3),"&c4=",d(k.c4,f),"&c5=",d(k.c5),"&c6=",d(k.c6),"&c10=",d(k.c10),"&c15=",d(k.c15),"&c16=",d(k.c16),"&c8=",d(j.title),"&c9=",d(j.referrer,f),"&cv=",i,k.r?"&r="+d(k.r,f):""].join("");a=a.length>2080?a.substr(0,2075)+"&ct=1":a;if(!/BlackBerry.*?\/([1-3]\.|4\.[0-5])/.test(b.userAgent)){var c=new Image();c.onload=function(){};c.src=a}else{a=a.replace(/\/b\?/,"/p?");j.write("<img src='"+a+"' />")}return a}catch(h){}};COMSCORE.purge=function(a){try{var c=[],f,b;a=a||_comscore;for(b=a.length-1;b>=0;b--){f=COMSCORE.beacon(a[b]);a.splice(b,1);if(f){c.push(f)}}return c}catch(d){}};COMSCORE.purge();





COMSCORE.beacon({c1:"8", c2:"18203330", c3:"1", c4:"", c5:"", c6:"", c10:"", c15:"", c16:"", r:""});



