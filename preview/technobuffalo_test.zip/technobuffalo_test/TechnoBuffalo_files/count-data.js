var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0","multiple":"{num}","one":"1"}},"counts":[{"id":"739171 http:\/\/www.technobuffalo.com\/?p=739171","comments":1},{"id":"739162 http:\/\/www.technobuffalo.com\/?p=739162","comments":0},{"id":"738658 http:\/\/www.technobuffalo.com\/?p=738658","comments":7},{"id":"739390 http:\/\/www.technobuffalo.com\/?p=739390","comments":10},{"id":"739375 http:\/\/www.technobuffalo.com\/?p=739375","comments":97},{"id":"739400 http:\/\/www.technobuffalo.com\/?p=739400","comments":16},{"id":"739372 http:\/\/www.technobuffalo.com\/?p=739372","comments":0}]});
}