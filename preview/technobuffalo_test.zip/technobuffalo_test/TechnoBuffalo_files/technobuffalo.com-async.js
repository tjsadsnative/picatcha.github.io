// technobuffalo.com

var _gaq = _gaq || [];
_gaq.push(['ns._setAccount', 'UA-25946851-21']);
_gaq.push(['ns._trackPageview']);
(function() {
	var ga = document.createElement('script');
	ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

var _comscore = _comscore || [];
  _comscore.push({ c1: "2", c2: "6036316" });
(function() {
    var coms = document.createElement("script"), el_coms = document.getElementsByTagName("script")[0]; coms.async = true;
    coms.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
    el_coms.parentNode.insertBefore(coms, el_coms);
})();
(function () { var d = "https:" === document.location.protocol ? "https://" : "http://", c = d + "zdbb.net/l/z0WVjCBSEeGLoxIxOQVEwQ", b = document.referrer, a = new Image().src = c + "?or=" + encodeURIComponent(b);  })();


(function(){var e=document.createElement("script");e.setAttribute("src","//cdn.static.zdbb.net/js/walker-min.js?v=0");document.body.appendChild(e)})();



(function () { var dc = document.cookie; if (dc.indexOf('_g_m=') == -1) { var dm = 'netshelter.net'; var z = "https:" === document.location.protocol ? "https://" : "http://", y = z + "gurgle.zdbb.net/?domain=", x = y + dm; var z = new Image().src = x; }})();
(function() {
  var nss = document.createElement("script"), el_nss = document.getElementsByTagName("script")[0];
  nss.src = "//secure-us.imrworldwide.com/v60.js";
  el_nss.parentNode.insertBefore(nss, el_nss);
  setTimeout(function() {
  pvar = { cid: "ziffdavis", content: "0", server: "secure-us" };
  try {
    var trac = nol_t(pvar);
    trac.record().post();
  } catch (e) {}
  }, 1000);
})();

(function() {
  var bkframe = document.createElement('iframe');
  bkframe.style.display = 'none';
  bkframe.src = 'about:blank';
  bkframe.name = '__bkframe';
  bkframe.height = 0;
  bkframe.width = 0;
  bkframe.frameborder = 0;
  bkframe.style.position = 'absolute';
  bkframe.style.clip = 'rect(0px 0px 0px 0px)';
  document.body.appendChild(bkframe);
  var bksrc = document.createElement('script');
  bksrc.src = '//tags.bkrtx.com/js/bk-coretag.js';
  bksrc.onload = function() {
    bk_doJSTag(20838, 10);
  };
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(bksrc, s);
})();

